//date
function date()
{
	var day = new Array("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
	var date = new Date()
	var year = date.getYear()
	if(year < 1000)
	{
		year += 1900
	
		var monthArray = new Array("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12")
	}
}
//time of day
function clock()
{
	var time = new Date()
	var hr = time.getHours()
	var min = time.getMinutes()
	var sec = time.getSeconds()
	var ampm = "PM"
	if (hr < 12)
	{
		ampm = "AM"
	}
	if (hr > 12)
	{
		hr -= 12
	}
	if (hr < 10)
	{
		hr = " " + hr
	}
	if (min < 10)
	{
		min = "0" + min
	}
	if (sec < 10)
	{
		sec = "0" + sec
	}

	
	//date
	var day = new Array("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
	var date = new Date()
	var year = date.getYear()
	if(year < 1000)
	{
		year += 1900

		var monthArray = new Array("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12")
	}


	setTimeout("clock()", 1000);

	if((sec) <= 10)
	{
		gaugePS.value=31;
		
		document.getElementById("1_tw_td").style.backgroundColor = "#0F0";
		document.getElementById("2_tw_td").style.backgroundColor = "#9F0";
		
		document.getElementById("3_tw_td").style.backgroundColor = "";
		document.getElementById("4_tw_td").style.backgroundColor = "";
		document.getElementById("5_tw_td").style.backgroundColor = "";
		document.getElementById("6_tw_td").style.backgroundColor = "";
	}
	else if((sec) <= 25)
	{
		gaugePS.value=37;
		
		document.getElementById("1_tw_td").style.backgroundColor = "#0F0";
		
		document.getElementById("2_tw_td").style.backgroundColor = "";
		document.getElementById("3_tw_td").style.backgroundColor = "";
		document.getElementById("4_tw_td").style.backgroundColor = "";
		document.getElementById("5_tw_td").style.backgroundColor = "";
		document.getElementById("6_tw_td").style.backgroundColor = "";	
	}
	else if((sec) <= 40)
	{
		gaugePS.value=43;
		
		document.getElementById("1_tw_td").style.backgroundColor = "#0F0";
		document.getElementById("2_tw_td").style.backgroundColor = "#9F0";
		document.getElementById("3_tw_td").style.backgroundColor = "#FF3";
		document.getElementById("4_tw_td").style.backgroundColor = "#F60";
		document.getElementById("5_tw_td").style.backgroundColor = "#F06";
	
		document.getElementById("6_tw_td").style.backgroundColor = "";
	}
	else if((sec) <= 50)
	{
		gaugePS.value=62.5;
		
		document.getElementById("1_tw_td").style.backgroundColor = "#0F0";
		document.getElementById("2_tw_td").style.backgroundColor = "#9F0";
		document.getElementById("3_tw_td").style.backgroundColor = "#FF3";
		document.getElementById("4_tw_td").style.backgroundColor = "#F60";
		
		document.getElementById("5_tw_td").style.backgroundColor = "";
		document.getElementById("6_tw_td").style.backgroundColor = "";	
	}
	else
	{
		gaugePS.value=27.5;
	
		document.getElementById("1_tw_td").style.backgroundColor = "#0F0";
		document.getElementById("2_tw_td").style.backgroundColor = "#9F0";
		document.getElementById("3_tw_td").style.backgroundColor = "#FF3";
		document.getElementById("4_tw_td").style.backgroundColor = "#F60";
		document.getElementById("5_tw_td").style.backgroundColor = "#F06";
		document.getElementById("6_tw_td").style.backgroundColor = "#F00";	
	}
	
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////



		var varCountControler = document.getElementById("txtCountControler").value;
		
		if(varCountControler == 1)
		{	
			var varTimmer = (44 - min);
			
			document.getElementById("txtWaitTime").innerHTML = varTimmer + "<br/>Min";
			
			document.getElementById("txtGetReady").innerHTML = varTimmer + "<br/>Min";
			
			if(varTimmer >= 11)
			{	
				document.getElementById("divGoIndicator").hidden = true;
				document.getElementById("divWaitTime").hidden = false;
				document.getElementById("divGetReady").hidden = true;
			}
			
			if(varTimmer < 11)
			{	
				document.getElementById("divGoIndicator").hidden = true;
				document.getElementById("divWaitTime").hidden = true;
				document.getElementById("divGetReady").hidden = false;
			}
			
			if(varTimmer < 1)
			{	
				document.getElementById("divGoIndicator").hidden = false;
				document.getElementById("divWaitTime").hidden = true;
				document.getElementById("divGetReady").hidden = true;
			}
			
			document.getElementById("divStartWaitCountDown").hidden = true;
		}
		else if(varCountControler == 0)
		{
			document.getElementById("divStartWaitCountDown").hidden = false;
			
			document.getElementById("divWaitTime").hidden = true;
			document.getElementById("divGoIndicator").hidden = true;
			document.getElementById("divGetReady").hidden = true;
		}

	
}